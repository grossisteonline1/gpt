# TikTok LIVE Monitor — regular website

A FastAPI backend with a responsive HTML/CSS/JavaScript dashboard and WebSocket live updates. It is not a Streamlit app.

## Features

- Responsive dark dashboard
- Start/stop a managed TikTokLive worker
- Reconnect attempts after connection failures
- First-eight-digit extraction across digit groups, matching the original algorithm
- Duplicate flag if the same detected number appears again within three minutes
- SQLite log persistence and CSV export
- Live table updates via WebSockets
- Search, duplicate-only filter, clear logs

## Run locally

Use Python 3.11 or 3.12 if possible.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
uvicorn app:app --reload
```

Open http://127.0.0.1:8000.

## Deploy online with Render

1. Create a GitHub repository and upload the contents of this folder.
2. In Render, choose **New → Blueprint** and select the repository containing `render.yaml`.
3. Deploy the service. The provided configuration uses a persistent disk for SQLite logs; persistent disks may require a paid Render plan.
4. Open the URL Render provides and test the dashboard.

You can also create a Render Web Service manually:
- Build command: `pip install -r requirements.txt`
- Start command: `uvicorn app:app --host 0.0.0.0 --port $PORT`
- Set `DATABASE_PATH` to a path on a persistent disk if you need logs to survive deploys/restarts.

## Important operational notes

- A live Python worker must remain running on the server. A static-site host alone is not enough.
- TikTokLive is an unofficial client library. TikTok may change its protocol or restrict connections; reconnect logic cannot guarantee availability.
- The current implementation runs one scraper worker per application process. Use a single web instance unless you implement shared coordination.
- SQLite data is stored on disk. Back up exported CSV files if the logs are important.
- There is no login/authentication in this starter. Before using a public URL, add authentication and restrict access; otherwise other visitors may start/stop the monitor or export/clear logs.
- Only monitor streams you are authorized to review. Phone numbers are personal data: ensure collection is lawful, limit access and retention, and avoid sharing exports publicly.
- The app does not collect TikTok passwords or attempt to bypass access controls.
