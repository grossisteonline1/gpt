const $ = (id) => document.getElementById(id);
let logs = [];
let status = { active: false, status: "Not connected", live_id: "", retry_count: 0 };
let socket;
let reconnectTimer;
let toastTimer;

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[ch]));
}
function showToast(message, isError = false) {
  const toast = $("toast");
  toast.textContent = message;
  toast.classList.toggle("error", isError);
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 3200);
}
function setStatus(next) {
  status = { ...status, ...next };
  $("connectionStat").textContent = status.active ? (status.status.toLowerCase().includes("connect") && status.status.toLowerCase().includes("connected") ? "Connected" : "Running") : (status.status === "Stopped" ? "Stopped" : "Idle");
  if (/connected to/i.test(status.status)) $("connectionStat").textContent = "Connected";
  $("statusDot").style.background = status.active ? (/connected to/i.test(status.status) ? "var(--green)" : "var(--amber)") : "var(--muted)";
  $("retryLabel").textContent = status.active ? (status.retry_count ? `Reconnect attempt ${status.retry_count}` : status.status) : status.status;
  $("startBtn").disabled = !!status.active;
  $("stopBtn").disabled = !status.active;
  $("livePill").classList.toggle("running", !!status.active);
  $("livePill").innerHTML = `<i></i>${status.active ? "Monitoring" : "Waiting"}`;
  if (status.live_id && !$("liveId").value) $("liveId").value = status.live_id;
}
function renderStats() {
  $("totalStat").textContent = logs.length.toLocaleString();
  $("spamStat").textContent = logs.filter(l => l.spam === "Yes").length.toLocaleString();
  const latest = logs.length ? logs[logs.length - 1].timestamp : "";
  $("lastActivity").textContent = latest ? new Date(latest).toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"}) : "—";
}
function renderLogs() {
  const query = $("searchInput").value.trim().toLowerCase();
  const spamOnly = $("spamOnly").checked;
  const filtered = logs.filter(log => {
    const matches = [log.timestamp, log.username, log.number, log.comment, log.spam].some(v => String(v ?? "").toLowerCase().includes(query));
    return matches && (!spamOnly || log.spam === "Yes");
  }).slice().reverse();
  $("rowCount").textContent = `${filtered.length} ${filtered.length === 1 ? "entry" : "entries"}`;
  $("footerCount").textContent = `Showing ${filtered.length} of ${logs.length} entries`;
  if (!filtered.length) {
    $("logBody").innerHTML = `<tr class="empty-row"><td colspan="5"><div class="empty-state"><div class="empty-symbol">⌁</div><b>${logs.length ? "No matching entries" : "No comments yet"}</b><span>${logs.length ? "Try changing your search or filters." : "Start monitoring a LIVE stream to see matching entries here."}</span></div></td></tr>`;
    renderStats();
    return;
  }
  $("logBody").innerHTML = filtered.map(log => {
    const date = new Date(log.timestamp);
    const dateLabel = Number.isNaN(date.getTime()) ? log.timestamp : date.toLocaleString([], {month:"short", day:"2-digit", hour:"2-digit", minute:"2-digit", second:"2-digit", hour12:false});
    const spam = log.spam === "Yes";
    return `<tr>
      <td class="time-cell">${escapeHtml(dateLabel)}</td>
      <td class="username-cell">${escapeHtml(log.username)}</td>
      <td class="number-cell">${escapeHtml(log.number)}</td>
      <td class="comment-cell" title="${escapeHtml(log.comment)}">${escapeHtml(log.comment)}</td>
      <td><span class="${spam ? "spam-badge" : "ok-badge"}">${spam ? "DUPLICATE" : "NEW"}</span></td>
    </tr>`;
  }).join("");
  renderStats();
}
async function request(url, options = {}) {
  const response = await fetch(url, { headers: {"Content-Type":"application/json", ...(options.headers || {})}, ...options });
  let data = {};
  try { data = await response.json(); } catch {}
  if (!response.ok) throw new Error(data.detail || `Request failed (${response.status})`);
  return data;
}
async function loadInitial() {
  try {
    const data = await request("/api/status");
    setStatus(data);
    const logData = await request("/api/logs");
    logs = logData.logs || [];
    renderLogs();
  } catch (err) {
    showToast(`Could not load dashboard: ${err.message}`, true);
  }
}
function connectWebSocket() {
  clearTimeout(reconnectTimer);
  const protocol = location.protocol === "https:" ? "wss:" : "ws:";
  socket = new WebSocket(`${protocol}//${location.host}/ws`);
  socket.onopen = () => {
    $("wsState").textContent = "Dashboard connected";
    $("wsState").previousElementSibling.style.background = "var(--green)";
  };
  socket.onmessage = event => {
    let message;
    try { message = JSON.parse(event.data); } catch { return; }
    if (message.type === "snapshot") {
      setStatus(message);
      if (Array.isArray(message.logs)) logs = message.logs;
      renderLogs();
    } else if (message.type === "status") {
      setStatus(message);
    } else if (message.type === "log") {
      if (!logs.some(log => log.id === message.log.id)) {
        logs.push(message.log);
        if (logs.length > 5000) logs = logs.slice(-5000);
        renderLogs();
      }
    } else if (message.type === "logs_cleared") {
      logs = [];
      renderLogs();
      showToast("Logs cleared.");
    }
  };
  socket.onclose = () => {
    $("wsState").textContent = "Reconnecting to dashboard";
    $("wsState").previousElementSibling.style.background = "var(--amber)";
    reconnectTimer = setTimeout(connectWebSocket, 1800);
  };
  socket.onerror = () => socket.close();
}
$("connectForm").addEventListener("submit", async event => {
  event.preventDefault();
  const liveId = $("liveId").value.trim().replace(/^@/, "");
  if (!liveId) return showToast("Enter a TikTok LIVE username first.", true);
  $("startBtn").disabled = true;
  try {
    const data = await request("/api/start", {method:"POST", body:JSON.stringify({live_id:liveId})});
    setStatus(data);
    showToast(`Monitor requested for @${liveId}.`);
  } catch (err) {
    showToast(err.message, true);
    $("startBtn").disabled = false;
  }
});
$("stopBtn").addEventListener("click", async () => {
  $("stopBtn").disabled = true;
  try {
    const data = await request("/api/stop", {method:"POST"});
    setStatus(data);
    showToast("Monitor stopped.");
  } catch (err) {
    showToast(err.message, true);
    $("stopBtn").disabled = false;
  }
});
$("refreshBtn").addEventListener("click", async () => {
  try {
    const data = await request("/api/logs");
    logs = data.logs || [];
    renderLogs();
    showToast("Logs refreshed.");
  } catch (err) { showToast(err.message, true); }
});
$("clearBtn").addEventListener("click", async () => {
  if (!confirm("Clear all saved logs? This cannot be undone.")) return;
  try {
    await request("/api/logs", {method:"DELETE"});
    logs = [];
    renderLogs();
    showToast("Saved logs cleared.");
  } catch (err) { showToast(err.message, true); }
});
$("searchInput").addEventListener("input", renderLogs);
$("spamOnly").addEventListener("change", renderLogs);
loadInitial();
connectWebSocket();
setInterval(() => {
  if (socket && socket.readyState === WebSocket.OPEN) socket.send("ping");
}, 25000);
