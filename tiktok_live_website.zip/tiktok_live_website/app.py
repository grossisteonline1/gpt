from __future__ import annotations

import asyncio
import csv
import io
import json
import logging
import os
import re
import sqlite3
import time
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("live-monitor")

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
DB_PATH = Path(os.getenv("DATABASE_PATH", str(BASE_DIR / "data" / "logs.sqlite3")))
SPAM_TIME_WINDOW = timedelta(minutes=3)
RECONNECT_DELAY_SECONDS = 5
MAX_LOG_ROWS = 5000

# Extract the first eight digits from all digit groups joined together.
def extract_eight_digit_numbers(comment: str) -> list[str]:
    digit_groups = re.findall(r"\d+", comment or "")
    cleaned_number = "".join(digit_groups)[:8]
    return [cleaned_number] if len(cleaned_number) == 8 else []

def utc_now() -> datetime:
    return datetime.now(timezone.utc)

def init_db() -> None:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                username TEXT NOT NULL,
                number TEXT NOT NULL,
                comment TEXT NOT NULL,
                spam TEXT NOT NULL
            )
        """)
        conn.commit()

def row_to_dict(row: tuple[Any, ...]) -> dict[str, Any]:
    return {
        "id": row[0], "timestamp": row[1], "username": row[2],
        "number": row[3], "comment": row[4], "spam": row[5]
    }

def load_logs(limit: int = MAX_LOG_ROWS) -> list[dict[str, Any]]:
    with sqlite3.connect(DB_PATH) as conn:
        rows = conn.execute(
            "SELECT id,timestamp,username,number,comment,spam FROM logs ORDER BY id DESC LIMIT ?",
            (limit,)
        ).fetchall()
    return [row_to_dict(r) for r in reversed(rows)]

def insert_log(entry: dict[str, str]) -> dict[str, Any]:
    with sqlite3.connect(DB_PATH) as conn:
        cur = conn.execute(
            "INSERT INTO logs(timestamp,username,number,comment,spam) VALUES(?,?,?,?,?)",
            (entry["timestamp"], entry["username"], entry["number"], entry["comment"], entry["spam"])
        )
        log_id = cur.lastrowid
        conn.commit()
    return {"id": log_id, **entry}

class ConnectionManager:
    def __init__(self) -> None:
        self.clients: set[WebSocket] = set()

    async def connect(self, websocket: WebSocket) -> None:
        await websocket.accept()
        self.clients.add(websocket)

    def disconnect(self, websocket: WebSocket) -> None:
        self.clients.discard(websocket)

    async def broadcast(self, payload: dict[str, Any]) -> None:
        dead = []
        message = json.dumps(payload, ensure_ascii=False)
        for ws in list(self.clients):
            try:
                await ws.send_text(message)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(ws)

class StartRequest(BaseModel):
    live_id: str = Field(min_length=2, max_length=100)

class ScraperController:
    def __init__(self) -> None:
        self.task: asyncio.Task | None = None
        self.client: Any = None
        self.live_id = ""
        self.status = "Not connected"
        self.active = False
        self.retry_count = 0
        self.recent_numbers: dict[str, datetime] = {}
        self.manager = ConnectionManager()
        self.lock = asyncio.Lock()

    async def publish_status(self, status: str) -> None:
        self.status = status
        await self.manager.broadcast({
            "type": "status", "status": self.status, "active": self.active,
            "live_id": self.live_id, "retry_count": self.retry_count
        })

    async def publish_log(self, log: dict[str, Any]) -> None:
        await self.manager.broadcast({"type": "log", "log": log})

    async def start(self, live_id: str) -> None:
        live_id = live_id.strip()
        if live_id.startswith("@"):
            live_id = live_id[1:]
        if not live_id or not re.fullmatch(r"[A-Za-z0-9._-]{2,100}", live_id):
            raise HTTPException(status_code=400, detail="Enter a valid TikTok Live username.")
        async with self.lock:
            if self.task and not self.task.done():
                if self.live_id.lower() == live_id.lower():
                    return
                raise HTTPException(status_code=409, detail="A scraper is already running. Stop it before changing accounts.")
            self.live_id = live_id
            self.active = True
            self.retry_count = 0
            self.task = asyncio.create_task(self._run(), name="tiktok-live-scraper")
        await self.publish_status(f"Starting @{live_id}…")

    async def stop(self) -> None:
        async with self.lock:
            self.active = False
            task = self.task
            client = self.client
            if task and not task.done():
                task.cancel()
        if client is not None:
            try:
                disconnect = getattr(client, "disconnect", None)
                if disconnect:
                    result = disconnect()
                    if asyncio.iscoroutine(result):
                        await result
            except Exception:
                logger.debug("Client disconnect during stop", exc_info=True)
        if task and task is not asyncio.current_task():
            try:
                await asyncio.wait_for(task, timeout=3)
            except (asyncio.CancelledError, asyncio.TimeoutError, Exception):
                pass
        self.task = None
        self.client = None
        await self.publish_status("Stopped")

    async def _run(self) -> None:
        try:
            # Lazy import means the website can start even if TikTokLive needs an update.
            from TikTokLive import TikTokLiveClient
            from TikTokLive.events import ConnectEvent, CommentEvent, DisconnectEvent

            while self.active:
                client = TikTokLiveClient(unique_id=self.live_id)
                self.client = client

                @client.on(ConnectEvent)
                async def on_connect(event: Any) -> None:
                    self.retry_count = 0
                    await self.publish_status(f"Connected to @{getattr(event, 'unique_id', self.live_id)}")

                @client.on(DisconnectEvent)
                async def on_disconnect(event: Any) -> None:
                    if self.active:
                        await self.publish_status("Disconnected — reconnecting…")

                @client.on(CommentEvent)
                async def on_comment(event: Any) -> None:
                    try:
                        comment = str(getattr(event, "comment", "") or "")
                        numbers = extract_eight_digit_numbers(comment)
                        if not numbers:
                            return
                        now = utc_now()
                        # Prune old entries so the in-memory deduplication map stays bounded.
                        cutoff = now - SPAM_TIME_WINDOW
                        self.recent_numbers = {n: ts for n, ts in self.recent_numbers.items() if ts >= cutoff}
                        user = getattr(event, "user", None)
                        username = (
                            getattr(user, "nickname", None)
                            or getattr(user, "unique_id", None)
                            or "unknown"
                        )
                        for number in numbers:
                            previous = self.recent_numbers.get(number)
                            is_spam = previous is not None and (now - previous) < SPAM_TIME_WINDOW
                            self.recent_numbers[number] = now
                            entry = {
                                "timestamp": now.isoformat(timespec="seconds"),
                                "username": str(username)[:120],
                                "number": number,
                                "comment": comment[:1000],
                                "spam": "Yes" if is_spam else "No",
                            }
                            saved = await asyncio.to_thread(insert_log, entry)
                            await self.publish_log(saved)
                    except Exception:
                        logger.exception("Error processing a TikTok comment")

                try:
                    await self.publish_status(f"Connecting to @{self.live_id}…")
                    await client.start()
                    # Some TikTokLive versions return when the connection ends.
                    if self.active:
                        await self.publish_status("Connection ended — reconnecting…")
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    self.retry_count += 1
                    logger.warning("TikTok connection failed (attempt %s): %s", self.retry_count, exc)
                    if self.active:
                        await self.publish_status(f"Connection failed — retry {self.retry_count} in {RECONNECT_DELAY_SECONDS}s")
                finally:
                    if self.client is client:
                        self.client = None
                if self.active:
                    await asyncio.sleep(RECONNECT_DELAY_SECONDS)
        except asyncio.CancelledError:
            pass
        except Exception as exc:
            logger.exception("Scraper worker stopped unexpectedly")
            await self.publish_status(f"Scraper error: {str(exc)[:180]}")
        finally:
            self.active = False
            self.client = None
            self.task = None
            if self.status != "Stopped":
                await self.publish_status("Not connected")

    def snapshot(self) -> dict[str, Any]:
        return {
            "type": "snapshot", "status": self.status, "active": self.active,
            "live_id": self.live_id, "retry_count": self.retry_count,
            "logs": load_logs()
        }

controller = ScraperController()

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield
    await controller.stop()

app = FastAPI(title="TikTok Live Monitor", version="1.0.0", lifespan=lifespan)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

@app.get("/")
async def home():
    return FileResponse(STATIC_DIR / "index.html")

@app.get("/api/status")
async def status():
    return controller.snapshot() | {"logs": None}

@app.get("/api/logs")
async def logs():
    return {"logs": load_logs()}

@app.post("/api/start")
async def start_scraper(request: StartRequest):
    await controller.start(request.live_id)
    return controller.snapshot() | {"logs": None}

@app.post("/api/stop")
async def stop_scraper():
    await controller.stop()
    return controller.snapshot() | {"logs": None}

@app.delete("/api/logs")
async def clear_logs():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("DELETE FROM logs")
        conn.commit()
    await controller.manager.broadcast({"type": "logs_cleared"})
    return {"ok": True}

@app.get("/api/export.csv")
async def export_csv():
    output = io.StringIO(newline="")
    writer = csv.DictWriter(output, fieldnames=["timestamp", "username", "number", "comment", "spam"])
    writer.writeheader()
    for row in load_logs(limit=1_000_000):
        writer.writerow({key: row[key] for key in writer.fieldnames})
    data = io.BytesIO(output.getvalue().encode("utf-8-sig"))
    filename = f"tiktok-live-logs-{datetime.now().strftime('%Y%m%d-%H%M%S')}.csv"
    return StreamingResponse(
        data, media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'}
    )

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await controller.manager.connect(websocket)
    try:
        await websocket.send_text(json.dumps(controller.snapshot(), ensure_ascii=False))
        while True:
            # Keep connection alive; client sends periodic ping frames as JSON.
            await websocket.receive_text()
    except WebSocketDisconnect:
        controller.manager.disconnect(websocket)
    except Exception:
        controller.manager.disconnect(websocket)
